package com.leaftaps.ui.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.pages.LoginPage;

import base.ProjectSpecificMethods;

public class TC001_CreateLead extends ProjectSpecificMethods{
	// 2. From the @BeforeTest and set the excel file name
	@BeforeTest
	public void setData() {
		excelFilePath = "./testData/tc001.xlsx";
	}
	// 1. From xml the control will come here and find the @Test alone
	// 6. From here start the execution
	@Test(dataProvider = "Dynamic_Data")
	public void runTC001(String username, String password, String companyName, String firstName, String lastName) {
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton_positive()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyName(companyName)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.clickCreateLeadButton()
		.verifyLeadID();
		
		
		/*
		 * LoginPage page = new LoginPage(); LoginPage enterUsername =
		 * page.enterUsername(username); LoginPage enterPassword =
		 * page.enterPassword(password); WelcomePage clickLoginButton_positive =
		 * page.clickLoginButton_positive();
		 * 
		 * WelcomePage page1 = new WelcomePage(); page1.clickCRMSFA();
		 */
		
		
	}
}
