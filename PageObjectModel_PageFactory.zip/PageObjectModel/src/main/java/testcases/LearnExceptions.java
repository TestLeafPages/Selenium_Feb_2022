package testcases;

import org.openqa.selenium.NoSuchElementException;

public class LearnExceptions {

	
	public static void main(String[] args) {
		
		int x = 10;
		int y = 0;
		int[] z = {1, 2, 3};
		
		try {
			System.out.println(x/y);
			System.out.println(z[3]);
		} catch (ArithmeticException e) {
			if(y==0) {
				System.out.println(x/1);
			}
			System.out.println(e);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
			throw new RuntimeException();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("Finally");
		}
		
		System.out.println("End of Program");
	}
}
