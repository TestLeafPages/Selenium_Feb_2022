package com.leaftaps.ui.pages;

import base.ProjectSpecificMethods;

public class MergeLeadPage extends ProjectSpecificMethods{

}
