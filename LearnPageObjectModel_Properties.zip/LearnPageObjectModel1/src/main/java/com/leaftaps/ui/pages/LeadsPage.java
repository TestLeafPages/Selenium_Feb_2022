package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class LeadsPage extends ProjectSpecificMethods{
public LeadsPage(RemoteWebDriver driver) {
	this.driver = driver;
}
public CreateLeadPage clickCreateLead() {
	driver.findElement(By.linkText(prop_lang.getProperty("createLead_linktext"))).click();
	return new CreateLeadPage(driver);
}
public MergeLeadPage clickMergeLead() {
	driver.findElement(By.linkText("Merge Lead")).click();
	return new MergeLeadPage();
}
}
