package property;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class LearnProperty {
public static void main(String[] args) throws IOException {
	// This class help me to read properties file
	Properties prop = new Properties();
	// Creating a new fileinputstream to make the given file as a readable comp
	FileInputStream file = new 
			FileInputStream(new File("src/main/resources/AppConfig.properties"));
	// Load the property Inputstream file
	prop.load(file);
	// To get the data out of properties file using the key
	String url = prop.getProperty("appURL");
	System.out.println(url);
	
}
}
